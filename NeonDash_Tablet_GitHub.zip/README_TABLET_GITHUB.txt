NEON DASH - Tablet + GitHub Cloud Build

This version includes a GitHub Actions workflow.

After uploading the project files to a GitHub repository:
1. Open the Actions tab.
2. Open "Build NEON DASH Android".
3. Run the workflow or push to main.
4. When it finishes, download the "neon-dash-aab" artifact.

IMPORTANT:
The generated release AAB is not Play Store-ready until it is properly signed with a release keystore. Keep the signing key private. Google Play publishing should be handled through an adult's developer account because the developer account holder must be 18+.
