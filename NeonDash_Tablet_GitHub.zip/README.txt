NEON DASH — Android Studio Project

What this is:
- Native Android application wrapper around the complete offline NEON DASH game.
- The HTML/JavaScript game is bundled in app/src/main/assets/index.html.
- Uses AndroidX WebViewAssetLoader to load local game content securely.
- No INTERNET permission is required because the game is offline.
- Portrait orientation.
- Package/application ID: com.neondash.game
- Version: 1.0 (versionCode 1)

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. For a test APK: Build > Build APK(s).
4. For Google Play: Build > Generate Signed Bundle / APK > Android App Bundle.
5. Create/select a release keystore when prompted.
6. The resulting .aab is the file used for Play Console submission.

Important:
- The Play Store listing also needs an app icon, screenshots, description, content declarations,
  privacy information where applicable, and other Play Console metadata.
- For a production release, increase versionCode for every update.
